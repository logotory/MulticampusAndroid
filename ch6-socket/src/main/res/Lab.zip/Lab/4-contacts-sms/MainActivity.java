package com.example.sector4_contacts_sms;

import android.Manifest;
import android.app.Activity;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.speech.RecognizerIntent;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.telephony.SmsManager;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    Button sendButton;
    Button voiceButton;
    Button contactButton;
    EditText phoneEdit;
    EditText contentEdit;

    boolean contactPermission;
    boolean smsPermission;
    boolean phonePermission;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        sendButton = (Button) findViewById(R.id.button_send);
        voiceButton = (Button) findViewById(R.id.button_voice);
        contactButton = (Button) findViewById(R.id.button_contacts);

        phoneEdit = (EditText) findViewById(R.id.edit_phone);
        contentEdit = (EditText) findViewById(R.id.edit_content);

        sendButton.setOnClickListener(this);
        voiceButton.setOnClickListener(this);
        contactButton.setOnClickListener(this);

        //add1~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


		//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    }



    public void onClick(View v) {
		//add2~~~~~~~~~~~~~~~~~~~~~~~~~

		//~~~~~~~~~~~~~~~~~~~~~~~~~~~~

    }





    BroadcastReceiver sentReceiver =
            new BroadcastReceiver() {
                @Override
                public void onReceive(Context _context, Intent _intent) {
                    String msg="";
                    switch (getResultCode()) {
                        case Activity.RESULT_OK:
                            // 전송 성공 처리; break;
                            msg="sms 전송 성공";
                            break;
                        case SmsManager.RESULT_ERROR_GENERIC_FAILURE:
                            // 일반적인 실패 처리; break;
                            msg="sms 전송 실패";
                            break;
                        case SmsManager.RESULT_ERROR_RADIO_OFF:
                            // 무선 꺼짐 처리; break;
                            msg="무선 꺼짐";
                            break;
                        case SmsManager.RESULT_ERROR_NULL_PDU:
                            // PDU 실패 처리; break;
                            msg="pdu 오류";
                            break;
                    }
                    Toast t = Toast.makeText(MainActivity.this, msg,
                            Toast.LENGTH_SHORT);
                    t.show();
                }
            };

    protected void onResume() {
        super.onResume();
        registerReceiver(sentReceiver, new IntentFilter("SENT_SMS_ACTION"));
    };
    @Override
    protected void onPause() {
        // TODO Auto-generated method stub
        super.onPause();
        unregisterReceiver(sentReceiver);
    }

}