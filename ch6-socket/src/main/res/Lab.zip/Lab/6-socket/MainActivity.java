package com.example.kakaochat;

import java.util.ArrayList;
import java.util.List;

import android.app.Activity;
import android.app.ActivityManager;
import android.app.ActivityManager.RunningServiceInfo;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;

public class MainActivity extends ActionBarActivity implements OnClickListener {

	ArrayList<ChatMessage> list;
	MyAdapter ap;

	ListView lv;
	Button sendBtn;
	EditText msgEdit;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		setContentView(R.layout.activity_main);

		lv = (ListView) findViewById(R.id.list);
		sendBtn = (Button) findViewById(R.id.send_btn);
		msgEdit = (EditText) findViewById(R.id.send_text);

		sendBtn.setOnClickListener(this);

		list = new ArrayList<ChatMessage>();
		ap = new MyAdapter(this, R.layout.list_item, list);
		lv.setAdapter(ap);

		lv.setDividerHeight(0);
		

		//lab1-----------------------------

		//lab1 end-------------------------
	}

	private void addMessage(String who, String msg) {
		ChatMessage vo = new ChatMessage();
		vo.who = who;
		vo.msg = msg;
		list.add(vo);
		ap.notifyDataSetChanged();
		lv.setSelection(list.size() - 1);
	}
//lab2------------------------------------------

//lab2 end------------------------------------
	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		if (!msgEdit.getText().toString().trim().equals("")) {

			Intent bcIntent = new Intent("com.kakao.ACTION_SERVICE_RECEIVER");
			bcIntent.putExtra("msg", msgEdit.getText().toString());
			sendBroadcast(bcIntent);

			addMessage("me", msgEdit.getText().toString());
			msgEdit.setText("");
		}
	}

}

class ChatMessage {
	String who;
	String msg;
}

class MyAdapter extends ArrayAdapter<ChatMessage> {
	ArrayList<ChatMessage> list;
	int resId;
	Context context;

	public MyAdapter(Context context, int resId, ArrayList<ChatMessage> list) {
		// TODO Auto-generated constructor stub
		super(context, resId, list);
		this.context = context;
		this.resId = resId;
		this.list = list;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		// TODO Auto-generated method stub
//		if (convertView == null) {
			LayoutInflater inflater = (LayoutInflater) context
					.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			convertView = inflater.inflate(resId, null);
//		}

		TextView msgView = (TextView) convertView.findViewById(R.id.msg);
		RelativeLayout.LayoutParams params = (RelativeLayout.LayoutParams) msgView
				.getLayoutParams();

		ChatMessage msg = list.get(position);
		if (msg.who.equals("me")) {
			params.addRule(RelativeLayout.ALIGN_PARENT_RIGHT,
					RelativeLayout.TRUE);
			msgView.setBackgroundColor(Color.YELLOW);
		} else if (msg.who.equals("you")) {
			params.addRule(RelativeLayout.ALIGN_PARENT_LEFT,
					RelativeLayout.TRUE);
			msgView.setBackgroundColor(Color.WHITE);
		}
		msgView.setText(msg.msg);

		return convertView;

	}
}
