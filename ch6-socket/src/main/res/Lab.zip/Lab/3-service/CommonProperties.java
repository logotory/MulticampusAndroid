package com.example.sector3_aidl;

public class CommonProperties {
	public static final int MEDIA_STATUS_STOP = 0;
	public static final int MEDIA_STATUS_RUNNING = 1;
	public static final int MEDIA_STATUS_COMPLETED = 2;
}
